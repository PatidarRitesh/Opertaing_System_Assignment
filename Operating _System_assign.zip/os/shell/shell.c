#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>

#include "tokenizer.h"

/* Convenience macro to silence compiler warnings about unused function parameters. */
#define unused __attribute__((unused))

/* Whether the shell is connected to an actual terminal or not. */
bool shell_is_interactive;

/* File descriptor for the shell input */
int shell_terminal;

/* Terminal mode settings for the shell */
struct termios shell_tmodes;

/* Process group id for the shell */
pid_t shell_pgid;

int cmd_exit(struct tokens* tokens);
int cmd_help(struct tokens* tokens);
//------------------------------------------------------------
// Adding function declaration for the cd and cwd commands too
int cmd_cd(struct tokens* tokens);
int cmd_cwd(struct tokens* tokens);
//------------------------------------------------------------

/* Built-in command functions take token array (see parse.h) and return int */
typedef int cmd_fun_t(struct tokens* tokens);

/* Built-in command struct and lookup table */
typedef struct fun_desc {
  cmd_fun_t* fun;
  char* cmd;
  char* doc;
} fun_desc_t;

fun_desc_t cmd_table[] = {
    {cmd_help, "?", "show this help menu"},
    {cmd_exit, "exit", "exit the command shell"},
    //------------------------------------------------------------
    // Adding the command to the cmd_table with their description 
    {cmd_cd, "cd", "Takes one argument, a directory path, and changes the current working directory to that directory"},
    {cmd_cwd, "cwd", "Prints the current working directory to standard output"}
    //------------------------------------------------------------
};

/* Prints a helpful description for the given command */
int cmd_help(unused struct tokens* tokens) {
  for (unsigned int i = 0; i < sizeof(cmd_table) / sizeof(fun_desc_t); i++)
    printf("%s - %s\n", cmd_table[i].cmd, cmd_table[i].doc);
  return 1;
}

/* Exits this shell */
int cmd_exit(unused struct tokens* tokens) { exit(0); }

/* Looks up the built-in command, if it exists. */
int lookup(char cmd[]) {
  for (unsigned int i = 0; i < sizeof(cmd_table) / sizeof(fun_desc_t); i++)
    if (cmd && (strcmp(cmd_table[i].cmd, cmd) == 0))
      return i;
  return -1;
}
//------------------------------------------------------------------------
/*This function will change the directory according to the given path
Note: cd command works only with one and only one path argument else it will fail*/
int cmd_cd(unused struct tokens* tokens){

  // If the cd command has more than one argument 
  if ( tokens_get_length(tokens) > 2){
    printf("Shell: cd: too many arguments\n");
    return -1;
  }

  // Get the path to the new_path pointer from the tokens object
  char* new_path = tokens_get_token(tokens, 1); 

  char* current_working_directory = (char *)malloc(sizeof(char)*4096);

  // chdir() command returns zero (0) on success. -1 is returned on an error and errno is set appropriately.
  if(chdir(new_path) != 0){
    // Path change failled
    printf("shell: cd: Assignment: No such file or directory\n");
    return -1;
  }
  else{
    getcwd(current_working_directory, 4096);
    printf("%s\n", current_working_directory);
  }
  return 1;
}

/*cmd_cwd() will print the current working directory path
*/
int cmd_cwd(unused struct tokens* tokens){
  char* current_working_directory = (char *)malloc(sizeof(char)*4096);

  if (getcwd(current_working_directory, 4096) == NULL){
    printf("Shell: cwd: Unable to fetch current working directory\n");
  }
  else{
    printf("%s\n",current_working_directory);
  }
  return 1;
}


/*exec_command() will execute all the valid commands that are not defined in the cmd_table
This function will use the execvp() to execute the command with its arguments. execvp can run commands without giving complete path of command*/
int exec_commmand(unused struct tokens* tokens){
  int arg_c, i=0, pid;
  static int  exec_result = 1;
  arg_c = (int) tokens_get_length(tokens);
  char* arg_v[arg_c];

  //Store all the tokens in the argument array arg_v
  while(i < arg_c)
  {
    arg_v[i] = tokens_get_token(tokens,i);
    i++;
  }arg_v[i] = NULL;   // argv:  is a null terminated array of character pointers. 

  // Here we are creating a fork(child function) to execute the command so that it will not damage the main shell in which it is executing
  pid = fork();
  if(pid == 0){
    exec_result = execvp(arg_v[0],arg_v);
    // printf("Exec-result %d\n",exec_result);  
    if (exec_result == -1)
      printf("%s: command not found\n",arg_v[0]);
    exit(0);
  } 
  else{
    // main process will wait for the child to finish the job
    wait(NULL);
    kill(pid,SIGKILL);

  }

  return exec_result;
}
//------------------------------------------------------------------------
/* Intialization procedures for this shell */
void init_shell() {
  /* Our shell is connected to standard input. */
  shell_terminal = STDIN_FILENO;

  /* Check if we are running interactively */
  shell_is_interactive = isatty(shell_terminal);

  if (shell_is_interactive) {
    /* If the shell is not currently in the foreground, we must pause the shell until it becomes a
     * foreground process. We use SIGTTIN to pause the shell. When the shell gets moved to the
     * foreground, we'll receive a SIGCONT. */
    while (tcgetpgrp(shell_terminal) != (shell_pgid = getpgrp()))
      kill(-shell_pgid, SIGTTIN);

    /* Saves the shell's process id */
    shell_pgid = getpid();

    /* Take control of the terminal */
    tcsetpgrp(shell_terminal, shell_pgid);

    /* Save the current termios to a variable, so it can be restored later. */
    tcgetattr(shell_terminal, &shell_tmodes);
  }
}

int main(unused int argc, unused char* argv[]) {
  init_shell();

  static char line[4096];
  int line_num = 0;

  /* Please only print shell prompts when standard input is not a tty */
  if (shell_is_interactive)
    fprintf(stdout, "%d: ", line_num);

  while (fgets(line, 4096, stdin)) {
    /* Split our line into words. */
    struct tokens* tokens = tokenize(line);

    /* Find which built-in function to run. */
    int fundex = lookup(tokens_get_token(tokens, 0));

    if (fundex >= 0) {
      cmd_table[fundex].fun(tokens);
    } else {
      /* REPLACE this to run commands as programs. */
      // fprintf(stdout, "This shell doesn't know how to run programs.\n");
      exec_commmand(tokens);

      // if(exec_result == -1){
      //   fprintf(stdout, "%s: command not found\n",tokens_get_token(tokens,0));
      // }

    }

    if (shell_is_interactive)
      /* Please only print shell prompts when standard input is not a tty */
      fprintf(stdout, "%d: ", ++line_num);

    /* Clean up memory */
    tokens_destroy(tokens);
  }

  return 0;
}
