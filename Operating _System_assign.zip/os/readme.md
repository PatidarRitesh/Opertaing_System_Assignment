# File Structure

> `shell`
> >  Makefile, shell.c shell.o tokenizer.c tokenizer.h

>  `word-count`
> > gutenburg: folder containing all the text files  
> > debug.c debug.h
> > list.c list.h list.o    
> > lwords, lwords.o, mwords   
> > Makefile    
> > word_count.h,  word_count.o    
> > word_count_l.c, word_count_l.o   
> > word_count_m.c   
> > word_helpers.h  word_helper.o   
> > words,  words.o

--------------

#  Solution files

## word-count/word_count_l.c
## word-count/word_count_m.c
## shell/shell.c

---------

# Executable

> lwords

> mwords

> words 

---------