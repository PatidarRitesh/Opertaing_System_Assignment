/*
Defining some macros : PINTOS_LIST and PTHREADS*/

#ifndef PINTOS_LIST
    #define PINTOS_LIST
#endif

#ifndef PTHREADS
    #define PTHREADS
#endif

#include<pthread.h>
#include "word_count.h"
#include "word_helpers.h"


// Declaring the word count list globally so that every thread can access it (or you can say, wclist is shared between threads)
word_count_list_t* wclist;

/*compute_count will be called by every thread function
It will open a file for each thread and call the count_words helper function declared in word_helpers.h file
This count_words function will implicitly call all the required function to read the file, tokenize the streams into words and
add the words into the word count list
Most of the functions used by count_words are defined in word_count_l.c*/
void * compute_count( void* arguments){    

    FILE *infile = fopen((char*)arguments,"r");

    count_words(wclist, infile);

    fclose(infile);
    return NULL;
}


/*This is the main function where the threading initializes and compute their tasks
1. Initialize the wclist 
2. Create the required threads
3. Join all the threads
4. Sort the final wclist formed after the completion of all the threads
5. And finally prints the list. 
*/

int main(int argc, char* argv[]){

    if( argc > 1){

        pthread_t thread1[argc-1];
        // Create and initialize wclist
        wclist = (word_count_list_t*)malloc(sizeof(word_count_list_t));
        init_words(wclist);

        // initialize the mutex lock of wclist
        if (pthread_mutex_init(&wclist->lock,NULL)!= 0 ){
            printf("Mutex init fail\n");
            return 1;
        }

        // Create the required threads and call the function - `compute_count()` with the argument - `filename`
        for(int j = 1; j<argc; j++){
            if(pthread_create(&thread1[j-1], NULL, compute_count, argv[j])!= 0){
                printf("Unable to create (%d) thread!",j);
                exit(-1);
            }
        }

        // Join all the threads with the main function so that main will wait for all the threads to complete
        for(int i = 1; i<argc; i++){
            if( pthread_join(thread1[i-1],NULL)!= 0){
                printf("Unable to join the thread %d",i);
                exit(-1);
            }
            // printf("Thread %d completed\n",i);
        }

        wordcount_sort(wclist,less_count);

        fprint_words(wclist, stdout); 

        pthread_mutex_destroy(&wclist->lock);

    }

    return 0;
}
