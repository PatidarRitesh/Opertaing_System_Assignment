/*
 * Implementation of the word_count interface using Pintos lists.
 *
 * You may modify this file, and are expected to modify it.
 */

/*
 * Copyright © 2021 University of California, Berkeley
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


#define PINTOS_LIST

//Added some header files to the code 
#include "word_count.h"
#include "word_helpers.h"

// init_word will take word_count_list type of argument and initialize the list (or list within the struct)
void init_words(word_count_list_t* wclist) { /* TODO */
  // When the Pthread is defined, wclist is a structure containig list and a lock, otherwise wclist is a list defined in list.c
  #ifdef PTHREADS
    list_init(&wclist->lst);
  #else
    list_init(wclist);
  #endif
}

// It will return the length of the list (or list within the structure) 
// With the help of list_size() defined in list.c file
size_t len_words(word_count_list_t* wclist) {
  /* TODO */
  #ifdef PTHREADS
    return list_size(&wclist->lst);
  #else
    return list_size(wclist);
  #endif
}

// This function will find a word inside a list 
// It will return NULL if the word is not found 
// Otherwise it will return the word_count_t typed object
word_count_t* find_word(word_count_list_t* wclist, char* word) {
  #ifdef PTHREADS
    struct word_count *temp_wc;
    struct list_elem *element;

    // Traversing through the list using the wclist argument.
    // Helping functions are list_begin() -> returns the first list element other than head
    // list_end -> return the tail element of the list
    // ------  Using `list_entry` it is finding the word_count object(which contains the data) of the respective list element.
    element = list_begin(&wclist->lst);
    while(element != list_end(&wclist->lst)){
      temp_wc =  list_entry(element, word_count_t, elem);
      if(strcmp(word, temp_wc->word) == 0)
        return temp_wc;
      element = list_next(element);
    }
  #else
    struct word_count *temp_wc;
    struct list_elem *element;
    element = list_begin(wclist);
    while(element != list_end(wclist)){
      temp_wc =  list_entry(element, word_count_t, elem);
      if(strcmp(word, temp_wc->word) == 0)
        return temp_wc;
      element = list_next(element);
    }
  #endif
  return NULL;
}
/*
This function will add the `word` to the iist if not exist, or increment the count if exist
add_word() will internally use the function find_word() to check if the word already exist or not?
*/
word_count_t* add_word(word_count_list_t* wclist, char* word) {
  /* TODO */

  #ifdef PTHREADS
    word_count_t *word_s;
    // Searching the word using find_word()
    pthread_mutex_lock(&wclist->lock);
    word_s = find_word(wclist, word);
    pthread_mutex_unlock(&wclist->lock);

    // If the word is not present in the list then
    // 1. Create a new object of word_count type, 
    // 2. Set the word and count 
    // 3. Insert the list_element of the object at the end of the list: (wclist or within wclist)
    if (word_s == NULL){
      word_s = (word_count_t* )malloc ( sizeof(word_count_t));
      word_s->word = word;
      word_s->count = 1;

      pthread_mutex_lock(&wclist->lock);
      list_push_back(&wclist->lst, &word_s->elem);  
      pthread_mutex_unlock(&wclist->lock);
    }
    else{
      pthread_mutex_lock(&wclist->lock);
      word_s->count += 1;
      pthread_mutex_unlock(&wclist->lock);
    }
    return word_s;
  #else
    word_count_t *word_s;
    word_s = find_word(wclist, word);


    if (word_s == NULL){
      word_s = (word_count_t* )malloc ( sizeof(word_count_t));
      word_s->word = word;
      word_s->count = 1;

      list_push_back(wclist, &word_s->elem);  
    }
    else{
      word_s->count += 1;
    }
    return word_s;
  #endif
}


/*fprint_words() will print all the words in the list defined by wclist*/
void fprint_words(word_count_list_t* wclist, FILE* outfile) { /* TODO */
  #ifdef PTHREADS
    struct list_elem* element;
    word_count_t* temp_wc;
    element = list_begin(&wclist->lst);
    while(element != list_end(&wclist->lst)){
      temp_wc =  list_entry(element, word_count_t, elem);
      fprintf(outfile, "%d   %s\n",temp_wc->count, temp_wc->word);
      element = list_next(element);
    }
  #else
    struct list_elem* element;
    word_count_t* temp_wc;
    element = list_begin(wclist);
    while(element != list_end(wclist)){
      temp_wc =  list_entry(element, word_count_t, elem);
      fprintf(outfile, "%d   %s\n",temp_wc->count, temp_wc->word);
      element = list_next(element);
    }
  #endif
}


/* 
This function will work as a `key` (or sorting parameter) to sort the list elements.
1. first it will find the word_count object of the respective list elements passed as arguments
2. call the less_count() defined inside the word_helpers.o
3. less_count() will compare the words according to their count and then alphabetical order or the words (when counts are equal)

*/
static bool less_list(const struct list_elem* ewc1, const struct list_elem* ewc2, void* aux) {
  /* TODO */
  word_count_t* wc1 = list_entry (ewc1, struct word_count, elem);
  word_count_t* wc2 = list_entry (ewc2, struct word_count, elem);

  return less_count(wc1, wc2);
}



void wordcount_sort(word_count_list_t* wclist,
                    bool less(const word_count_t*, const word_count_t*)) {
  #ifdef PTHREADS 
    list_sort(&wclist->lst, less_list, less); 
  #else
    list_sort(wclist, less_list, less);
  #endif 
}
